#SKD101|tanphu_tracnghiem|21|2008.07.19 16:34:05|148|93|6|5|3|6|30|1|1|3

DROP TABLE IF EXISTS `tracnghiem_answers`;
CREATE TABLE `tracnghiem_answers` (
  `answerid` int(10) unsigned NOT NULL default '0',
  `questionid` int(10) unsigned NOT NULL default '0',
  `answer_text` text NOT NULL,
  `answer_feedback` text NOT NULL,
  `answer_correct` tinyint(3) unsigned NOT NULL default '0',
  `answer_percents` float NOT NULL default '0',
  `isregexp` tinyint(3) unsigned NOT NULL default '0',
  `iscasesensitive` tinyint(3) unsigned NOT NULL default '1',
  PRIMARY KEY  (`questionid`,`answerid`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=latin1 */;

DROP TABLE IF EXISTS `tracnghiem_config`;
CREATE TABLE `tracnghiem_config` (
  `configid` int(10) unsigned NOT NULL default '0',
  `config_name` varchar(50) NOT NULL default '',
  `config_value` text NOT NULL,
  PRIMARY KEY  (`configid`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=latin1 */;

INSERT INTO `tracnghiem_config` VALUES
(1, 'igttimestamp', '1185953317'),
(2, 'igtversion', '2.1.0'),
(3, 'can_register', '1'),
(4, 'reg_intro', '<b>Xin chào các bạn, Hiện nay công nghệ thông tin ngày càng được sử dụng rộng rãi trong giáo dục và giảng dạy. Vì vậy mình mong trang trắc nghiệm trực tuyến của Tânphú.Net sẽ giúp ích các bạn trong việc học tập và luyện thi . Đề trên Website được các giáo viên của trường THPt chuyên ban Tân Phú, Định Quán, Đồng Nai biên soạn và sưu tầm. Chúc bạn học giỏi, thành công !\r\n<br><br>\r\nĐể hoàn tất quá trình đăng kí, bạn hãy điền đầy đủ thông tin vào các ô dưới đây !\r\n<br><br>\r\nMọi ý kiến đóng góp xin gửi: VuThanhLai@Gmail.Com hoặc Y!M: KiUcTinhYeu_1811 .</b>'),
(5, 'reg_username', '4'),
(6, 'reg_password', '4'),
(7, 'reg_email', '4'),
(8, 'reg_firstname', '4'),
(9, 'reg_lastname', '4'),
(10, 'reg_middlename', '0'),
(11, 'reg_address', '4'),
(12, 'reg_city', '4'),
(13, 'reg_state', '4'),
(14, 'reg_zip', '0'),
(15, 'reg_country', '4'),
(16, 'reg_phone', '0'),
(17, 'reg_fax', '0'),
(18, 'reg_mobile', '0'),
(19, 'reg_pager', '0'),
(20, 'reg_ipphone', '0'),
(21, 'reg_webpage', '0'),
(22, 'reg_icq', '0'),
(23, 'reg_msn', '0'),
(24, 'reg_gender', '4'),
(25, 'reg_birthday', '0'),
(26, 'reg_photo', '0'),
(27, 'reg_company', '0'),
(28, 'reg_jobtitle', '0'),
(29, 'reg_department', '0'),
(30, 'reg_office', '0'),
(31, 'reg_caddress', '0'),
(32, 'reg_ccity', '0'),
(33, 'reg_cstate', '0'),
(34, 'reg_czip', '0'),
(35, 'reg_ccountry', '0'),
(36, 'reg_cphone', '0'),
(37, 'reg_cfax', '0'),
(38, 'reg_cmobile', '0'),
(39, 'reg_cpager', '0'),
(40, 'reg_cipphone', '0'),
(41, 'reg_cwebpage', '0'),
(42, 'reg_trainer', '0'),
(43, 'reg_userfield1', '4'),
(44, 'reg_caption_userfield1', 'Lớp (VD:12a2)'),
(45, 'reg_userfield2', '4'),
(46, 'reg_caption_userfield2', 'Trường(VD: THPT-TânPhú)'),
(47, 'reg_userfield3', '0'),
(48, 'reg_caption_userfield3', ''),
(49, 'reg_userfield4', '0'),
(50, 'reg_caption_userfield4', ''),
(51, 'list_length', '30'),
(52, 'store_logs', '0'),
(53, 'editor_type', '3'),
(54, 'upon_registration', '0'),
(55, 'reg_title', '0'),
(56, 'reg_aol', '0'),
(57, 'reg_husbandwife', '0'),
(58, 'reg_children', '0'),
(59, 'reg_cphoto', '0'),
(60, 'reg_userfield5', '0'),
(61, 'reg_caption_userfield5', ''),
(62, 'reg_userfield6', '0'),
(63, 'reg_caption_userfield6', ''),
(64, 'reg_userfield7', '0'),
(65, 'reg_caption_userfield7', ''),
(66, 'reg_userfield8', '0'),
(67, 'reg_caption_userfield8', ''),
(68, 'reg_userfield9', '0'),
(69, 'reg_caption_userfield9', ''),
(70, 'reg_userfield10', '0'),
(71, 'reg_caption_userfield10', ''),
(72, 'reg_type_userfield1', '0'),
(73, 'reg_values_userfield1', ''),
(74, 'reg_type_userfield2', '0'),
(75, 'reg_values_userfield2', ''),
(76, 'reg_type_userfield3', '0'),
(77, 'reg_values_userfield3', '0'),
(78, 'reg_type_userfield4', '0'),
(79, 'reg_values_userfield4', ''),
(80, 'reg_type_userfield5', '0'),
(81, 'reg_values_userfield5', ''),
(82, 'reg_type_userfield6', '0'),
(83, 'reg_values_userfield6', ''),
(84, 'reg_type_userfield7', '0'),
(85, 'reg_values_userfield7', ''),
(86, 'reg_type_userfield8', '0'),
(87, 'reg_values_userfield8', ''),
(88, 'reg_type_userfield9', '0'),
(89, 'reg_values_userfield9', ''),
(90, 'reg_type_userfield10', '0'),
(91, 'reg_values_userfield10', ''),
(92, 'default_language', 'en'),
(93, 'version', '23f7dbd2c67658ce8ceffc1ce97bbba2');

DROP TABLE IF EXISTS `tracnghiem_etemplates`;
CREATE TABLE `tracnghiem_etemplates` (
  `etemplateid` int(10) unsigned NOT NULL auto_increment,
  `etemplate_name` varchar(255) NOT NULL default '',
  `etemplate_description` varchar(255) NOT NULL default '',
  `etemplate_from` varchar(255) NOT NULL default '',
  `etemplate_subject` varchar(255) NOT NULL default '',
  `etemplate_body` text NOT NULL,
  PRIMARY KEY  (`etemplateid`)
) ENGINE=MyISAM AUTO_INCREMENT=51 /*!40101 DEFAULT CHARSET=latin1 */;

INSERT INTO `tracnghiem_etemplates` VALUES
(1, 'Kế quả Kiểm tra  (Mặc định)', 'Khung mẫu Email kết quả kiểm tra(Mặc định)', 'vuthanhlai@gmail.com', 'TânPhú.Net Tested - Báo cáo Mẫu', 'Chào [USER_FIRST_NAME],\r\n\r\nở đây những kết quả từ bài kiểm (của) các bạn:\r\n\r\nTên bài kiểm: [TEST_NAME]\r\nNgày: [RESULT_DATE]\r\nThời gian: [RESULT_TIME_SPENT]\r\nThời gian được vượt hơn: [RESULT_TIME_EXCEEDED]\r\n\r\n[RESULT_DETAILED_1]\r\n\r\nThổng điểm: [RESULT_POINTS_SCORED] / [RESULT_POINTS_POSSIBLE] ([RESULT_PERCENTS]%)\r\nXếp loại: [RESULT_GRADE]\r\n\r\nThân chào,chúc bạn học tốt và thành công trong tương lai !\r\nAdmin: Vũ Thanh Lai | Email: VuThanhLai@Gmail.Com | Y!M: KiUcTinhYeu_1811 | Site: http://tanphu.net '),
(2, 'Tài khoản đăng ký', 'khung mẫu email Tài khoản đăng ký ', 'vuthanhlai@gmail.com', 'Những chi tiết Đăng ký', 'Chào [USER_FIRST_NAME],\r\n\r\nCảm ơn bạn đăng ký Với TânPhú.Net (http://tracnghiem.tanphu.net).\r\n\r\nUsername: [USERNAME]\r\nPassword: [USER_PASSWORD]\r\n\r\nBạn có thể đăng nhập tới tài khoản (của) các bạn bất kỳ thời gian nào đến thăm:\r\n\r\n[TânPhú.Net Tested_URL]\r\n\r\nThân chào,chúc bạn học tốt và thành công trong tương lai !\r\nAdmin: Vũ Thanh Lai | Email: VuThanhLai@Gmail.Com | Y!M: KiUcTinhYeu_1811 | Site: http://tanphu.net '),
(3, 'Account Sign Up (Email Activation)', 'Tài khoản đăng ký khung mẫu email', 'vuthanhlai@gmail.com', 'Sự Kích hoạt Tài khoản', 'Chào [USER_FIRST_NAME],\r\n\r\nCảm ơn bạn đăng ký Với TânPhú.Net (http://tracnghiem.tanphu.net).\r\n\r\nUsername: [USERNAME]\r\nPassword: [USER_PASSWORD]\r\n\r\nTiếp theo bạn hãy làm như sau :\r\n\r\nĐể hoàn thành việc kích hoạt tài khoản (của) các bạn, xin kích vào mối liên kết sau đây\r\n\r\n[TânPhú.Net Tested_URL]/account.php?action=activate&userid=[USER_ID]&checkword=[USER_CHECKWORD]\r\n\r\nThân chào,chúc bạn học tốt và thành công trong tương lai !\r\nAdmin: Vũ Thanh Lai | Email: VuThanhLai@Gmail.Com | Y!M: KiUcTinhYeu_1811 | Site: http://tanphu.net '),
(4, 'Tài khoản đã Được kích hoạt', 'Khung mẫu email được kích hoạt Tài khoản', 'vuthanhlai@gmail.com', 'Tài khoản Được kích hoạt', 'Thân mến [USER_FIRST_NAME],\r\n\r\nTài khoản (của) Các bạn đã được kích hoạt một cách thành công .\r\n\r\nBạn có thể đăng nhập tới tài khoản (của) các bạn bất kỳ thời gian nào đến thăm:\r\n\r\n[TânPhú.Net Tested_URL]\r\n\r\nThân chào,chúc bạn học tốt và thành công trong tương lai !\r\nAdmin: Vũ Thanh Lai | Email: VuThanhLai@Gmail.Com | Y!M: KiUcTinhYeu_1811 | Site: http://tanphu.net '),
(5, 'Tài khoản đăng ký ((cho) Người quản trị)', 'Tài khoản đăng ký khung mẫu email', 'vuthanhlai@gmail.com', 'Những chi tiết Đăng ký Người sử dụng Mới', 'Thân mến Administrator,\r\n\r\nNhững chi tiết đăng ký người sử dụng Mới:\r\n\r\nHọ [USER_FIRST_NAME]\r\nTên: [USER_LAST_NAME]\r\nEmail: [USER_EMAIL]\r\nUsername: [USERNAME]\r\nPassword: [USER_PASSWORD]\r\n\r\nThân chào,chúc bạn học tốt và thành công trong tương lai !\r\nAdmin: Vũ Thanh Lai | Email: VuThanhLai@Gmail.Com | Y!M: KiUcTinhYeu_1811 | Site: http://tanphu.net '),
(50, 'Khôi phục mật khẩu', 'Password recovery email template', 'vuthanhlai@gmail.com', 'Khôi phục mật khẩu', 'Xin chào [USER_FIRST_NAME],\r\n\r\nChúng tôi đã tạo mật khẩu mới cho bạn.\r\n\r\nUsername: [USERNAME]\r\nMât khẩu mới: [USER_PASSWORD]\r\n\r\nThân chào,chúc bạn học tốt và thành công trong tương lai !\r\nAdmin: Vũ Thanh Lai | Email: VuThanhLai@Gmail.Com | Y!M: KiUcTinhYeu_1811 | Site: http://tanphu.net ');

DROP TABLE IF EXISTS `tracnghiem_groups`;
CREATE TABLE `tracnghiem_groups` (
  `groupid` int(10) unsigned NOT NULL auto_increment,
  `group_name` varchar(255) NOT NULL default '',
  `group_description` varchar(255) NOT NULL default '',
  `access_tests` tinyint(3) unsigned NOT NULL default '1',
  `access_testmanager` tinyint(3) unsigned NOT NULL default '0',
  `access_gradingsystems` tinyint(3) unsigned NOT NULL default '0',
  `access_emailtemplates` tinyint(3) unsigned NOT NULL default '0',
  `access_reporttemplates` tinyint(3) unsigned NOT NULL default '0',
  `access_reportsmanager` tinyint(3) unsigned NOT NULL default '0',
  `access_questionbank` tinyint(3) unsigned NOT NULL default '0',
  `access_subjects` tinyint(3) unsigned NOT NULL default '0',
  `access_groups` tinyint(3) unsigned NOT NULL default '0',
  `access_users` tinyint(3) unsigned NOT NULL default '0',
  `access_visitors` tinyint(3) unsigned NOT NULL default '0',
  `access_config` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`groupid`)
) ENGINE=MyISAM AUTO_INCREMENT=21 /*!40101 DEFAULT CHARSET=latin1 */;

INSERT INTO `tracnghiem_groups` VALUES
(1, 'Administrators', 'Những người quản trị có sự truy nhập không giới hạn và đầy đủ (nhóm hệ thống)', 2, 2, 2, 2, 2, 3, 2, 2, 2, 4, 2, 2),
(2, 'Giáo viên', 'Những thầy giáo sở hữu đa số quyền hành chính với một số sự hạn chế ( Nhóm hệ thống)', 2, 2, 2, 2, 2, 3, 2, 2, 1, 3, 1, 1),
(3, 'Thao tác viên', 'Những thành viên trong nhóm này được ban quyền để tạo ra/ những câu hỏi soạn thảo (nhóm hệ thống)', 1, 1, 0, 0, 0, 0, 2, 2, 0, 3, 0, 0),
(19, 'Người dùng', 'Những người sử dụng bị ngăn ngừa làm sẵn đến từ bất kỳ sự thay đổi ngẫu nhiên hay định trước nào (nhóm hệ thống)', 2, 0, 0, 0, 0, 1, 0, 0, 0, 3, 0, 0),
(20, 'Khách', 'Những khách có cùng sự truy nhập với những thành viên (của) những nhóm người dùng theo mặc định (nhóm hệ thống)', 2, 0, 0, 0, 0, 1, 0, 0, 0, 3, 0, 0);

DROP TABLE IF EXISTS `tracnghiem_groups_resources`;
CREATE TABLE `tracnghiem_groups_resources` (
  `groupid` int(10) unsigned NOT NULL default '0',
  `resourceid` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`groupid`,`resourceid`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=latin1 */;

DROP TABLE IF EXISTS `tracnghiem_groups_tests`;
CREATE TABLE `tracnghiem_groups_tests` (
  `groupid` int(10) unsigned NOT NULL default '0',
  `testid` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`groupid`,`testid`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=latin1 */;

DROP TABLE IF EXISTS `tracnghiem_groups_users`;
CREATE TABLE `tracnghiem_groups_users` (
  `groupid` int(10) unsigned NOT NULL default '0',
  `userid` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`groupid`,`userid`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=latin1 */;

INSERT INTO `tracnghiem_groups_users` VALUES
(1, 1),
(19, 3),
(20, 2);

DROP TABLE IF EXISTS `tracnghiem_gscales`;
CREATE TABLE `tracnghiem_gscales` (
  `gscaleid` int(10) unsigned NOT NULL auto_increment,
  `gscale_name` varchar(255) NOT NULL default '',
  `gscale_description` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`gscaleid`)
) ENGINE=MyISAM AUTO_INCREMENT=7 /*!40101 DEFAULT CHARSET=latin1 */;

INSERT INTO `tracnghiem_gscales` VALUES
(1, 'A-F Sắp xếp Quy mô (60% thứ bậc chuyển qua)', 'A-F grading scale'),
(2, 'Passed/Not Passed Grading Scale', 'Passed/not passed grading scale'),
(3, 'ECTS Grading Scale', 'ECTS (European Credit Transfer System) grading scale'),
(4, 'GPA Grading Scale', 'GPA (Grade Point Average) grading scale'),
(5, '6-Point Grading Scale (Germany)', '6-point grading scale in Germany'),
(6, '5-Point Grading Scale (Central and Eastern Europe)', '5-point grading scale in Central and Eastern Europe');

DROP TABLE IF EXISTS `tracnghiem_gscales_grades`;
CREATE TABLE `tracnghiem_gscales_grades` (
  `gscaleid` int(10) unsigned NOT NULL default '0',
  `gscale_gradeid` int(10) unsigned NOT NULL default '0',
  `grade_name` varchar(255) NOT NULL default '',
  `grade_description` varchar(255) NOT NULL default '',
  `grade_feedback` text NOT NULL,
  `grade_from` float NOT NULL default '0',
  `grade_to` float NOT NULL default '0',
  `isabsolute` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`gscaleid`,`gscale_gradeid`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=latin1 */;

INSERT INTO `tracnghiem_gscales_grades` VALUES
(1, 1, 'A', 'Excellent', '', '90', '100', 0),
(1, 2, 'B', 'Good', '', '80', '90', 0),
(1, 3, 'C', 'Fair', '', '70', '80', 0),
(1, 4, 'D', 'Poor', '', '60', '70', 0),
(1, 5, 'F', 'Fail', '', '0', '60', 0),
(2, 1, 'Passed', 'Passed', '', '50', '100', 0),
(2, 2, 'Not Passed', 'Not passed', '', '0', '50', 0),
(3, 1, 'A', 'Excellent (outstanding performance with only minor errors)', '', '95', '100', 0),
(3, 2, 'B', 'Very good (above the average standard but with some errors)', '', '90', '95', 0),
(3, 3, 'C', 'Good (generally sound work with a number of notable errors)', '', '85', '90', 0),
(3, 4, 'D', 'Satisfactory (fair but with significant shortcomings)', '', '80', '85', 0),
(3, 5, 'E', 'Sufficient (performance meets the minimum criteria)', '', '75', '80', 0),
(3, 6, 'FX', 'Fail (some more work required before the credit can be awarded)', '', '65', '75', 0),
(3, 7, 'F', 'Fail (considerable further work is required)', '', '0', '65', 0),
(4, 1, '4', 'Tuyệt vời', '', '90', '100', 0),
(4, 2, '3', 'Giỏi', '', '80', '90', 0),
(4, 3, '2', 'Fair', '', '70', '80', 0),
(4, 4, '1', 'Poor', '', '60', '70', 0),
(4, 5, '0', 'Fail', '', '0', '60', 0),
(5, 1, '1', 'Excellent', '', '90', '100', 0),
(5, 2, '2', 'Good', '', '80', '90', 0),
(5, 3, '3', 'Satisfactory', '', '70', '80', 0),
(5, 4, '4', 'Sufficient', '', '60', '70', 0),
(5, 5, '5', 'Unsatisfactory', '', '50', '60', 0),
(5, 6, '6', 'Poor', '', '0', '50', 0),
(6, 1, '5', 'Excellent', '', '90', '100', 0),
(6, 2, '4', 'Good', '', '80', '90', 0),
(6, 3, '3', 'Satisfactory', '', '70', '80', 0),
(6, 4, '2', 'Unsatisfactory', '', '60', '70', 0),
(6, 5, '1', 'Poor', '', '0', '60', 0);

DROP TABLE IF EXISTS `tracnghiem_questions`;
CREATE TABLE `tracnghiem_questions` (
  `questionid` int(10) unsigned NOT NULL auto_increment,
  `subjectid` int(10) unsigned NOT NULL default '1',
  `question_time` int(10) unsigned NOT NULL default '0',
  `question_pre` text NOT NULL,
  `question_post` text NOT NULL,
  `question_text` text NOT NULL,
  `question_points` float NOT NULL default '1',
  `question_solution` text NOT NULL,
  `question_type` int(10) unsigned NOT NULL default '0',
  `question_type2` tinyint(3) unsigned NOT NULL default '0',
  `question_shufflea` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`questionid`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=latin1 */;

DROP TABLE IF EXISTS `tracnghiem_resources`;
CREATE TABLE `tracnghiem_resources` (
  `resourceid` int(10) unsigned NOT NULL auto_increment,
  `resource_testid` int(10) unsigned NOT NULL default '0',
  `resource_name` varchar(255) NOT NULL default '',
  `resource_description` varchar(255) NOT NULL default '',
  `resource_url` text NOT NULL,
  `resource_html` text NOT NULL,
  `resource_datestart` int(10) unsigned NOT NULL default '0',
  `resource_dateend` int(10) unsigned NOT NULL default '0',
  `resource_forall` tinyint(3) unsigned NOT NULL default '1',
  `resource_createdate` int(10) unsigned NOT NULL default '0',
  `resource_enabled` tinyint(3) unsigned NOT NULL default '1',
  PRIMARY KEY  (`resourceid`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=latin1 */;

DROP TABLE IF EXISTS `tracnghiem_results`;
CREATE TABLE `tracnghiem_results` (
  `resultid` int(10) unsigned NOT NULL auto_increment,
  `testid` int(10) unsigned NOT NULL default '0',
  `userid` int(10) unsigned NOT NULL default '0',
  `result_datestart` int(10) unsigned NOT NULL default '0',
  `result_timespent` int(10) unsigned NOT NULL default '0',
  `result_timeexceeded` tinyint(3) unsigned NOT NULL default '0',
  `result_points` float NOT NULL default '0',
  `result_pointsmax` float NOT NULL default '0',
  `gscaleid` int(10) unsigned NOT NULL default '1',
  `gscale_gradeid` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`resultid`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=latin1 */;

DROP TABLE IF EXISTS `tracnghiem_results_answers`;
CREATE TABLE `tracnghiem_results_answers` (
  `result_answerid` int(10) unsigned NOT NULL default '0',
  `resultid` int(10) unsigned NOT NULL default '0',
  `questionid` int(10) unsigned NOT NULL default '0',
  `test_questionid` int(10) unsigned NOT NULL default '0',
  `result_answer_text` text NOT NULL,
  `result_answer_points` float NOT NULL default '0',
  `result_answer_iscorrect` tinyint(3) unsigned NOT NULL default '0',
  `result_answer_feedback` text NOT NULL,
  `result_answer_timespent` int(10) unsigned NOT NULL default '0',
  `result_answer_timeexceeded` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`resultid`,`result_answerid`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=latin1 */;

DROP TABLE IF EXISTS `tracnghiem_rtemplates`;
CREATE TABLE `tracnghiem_rtemplates` (
  `rtemplateid` int(10) unsigned NOT NULL auto_increment,
  `rtemplate_name` varchar(255) NOT NULL default '',
  `rtemplate_description` varchar(255) NOT NULL default '',
  `rtemplate_body` text NOT NULL,
  PRIMARY KEY  (`rtemplateid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 /*!40101 DEFAULT CHARSET=latin1 */;

INSERT INTO `tracnghiem_rtemplates` VALUES
(1, 'Report Template #1', 'Report template #1', '<h1>[TEST_NAME]</h1>\r\n<p><strong>Ngày:</strong> [RESULT_DATE]</p>\r\n<p><strong>Tên:</strong> [USER_LAST_NAME]<br>\r\n<strong>Họ</strong> [USER_FIRST_NAME]<br>\r\n<strong>Thời gian làm:</strong> [RESULT_TIME_SPENT]<br>\r\n<strong>Điểm:</strong> [RESULT_POINTS_SCORED] / [RESULT_POINTS_POSSIBLE] ([RESULT_PERCENTS]%)<br>\r\n<strong>Xếp loại:</strong> [RESULT_GRADE]</p>\r\n<p><strong>Chi tiết:</strong><br>[RESULT_DETAILED_1]</p>');

DROP TABLE IF EXISTS `tracnghiem_subjects`;
CREATE TABLE `tracnghiem_subjects` (
  `subjectid` int(10) unsigned NOT NULL auto_increment,
  `subject_parent_subjectid` int(10) unsigned NOT NULL default '0',
  `subject_name` varchar(255) NOT NULL default '',
  `subject_description` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`subjectid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 /*!40101 DEFAULT CHARSET=latin1 */;

INSERT INTO `tracnghiem_subjects` VALUES
(1, 0, '[Ko có tên đề tài]', 'Không có đề tài nào');

DROP TABLE IF EXISTS `tracnghiem_tests`;
CREATE TABLE `tracnghiem_tests` (
  `testid` int(10) unsigned NOT NULL auto_increment,
  `subjectid` int(10) unsigned NOT NULL default '1',
  `rtemplateid` int(10) unsigned NOT NULL default '1',
  `result_etemplateid` int(10) unsigned NOT NULL default '0',
  `gscaleid` int(10) unsigned NOT NULL default '1',
  `test_type` int(10) unsigned NOT NULL default '0',
  `test_name` varchar(255) NOT NULL default '',
  `test_code` varchar(255) NOT NULL default '',
  `test_description` varchar(255) NOT NULL default '',
  `test_instructions` text NOT NULL,
  `test_time` int(10) unsigned NOT NULL default '0',
  `test_timeforceout` tinyint(3) unsigned NOT NULL default '0',
  `test_timingq` tinyint(3) unsigned NOT NULL default '0',
  `test_attempts` int(10) unsigned NOT NULL default '0',
  `test_shuffleq` tinyint(3) unsigned NOT NULL default '0',
  `test_shufflea` tinyint(3) unsigned NOT NULL default '0',
  `test_sectionstype` int(10) unsigned NOT NULL default '0',
  `test_qsperpage` tinyint(3) unsigned NOT NULL default '1',
  `test_showqfeedback` tinyint(3) unsigned NOT NULL default '1',
  `test_canreview` tinyint(3) unsigned NOT NULL default '0',
  `test_result_showanswers` tinyint(3) unsigned NOT NULL default '0',
  `test_result_showpoints` tinyint(3) unsigned NOT NULL default '1',
  `test_result_showgrade` tinyint(3) unsigned NOT NULL default '0',
  `test_result_showgradefeedback` tinyint(3) unsigned NOT NULL default '0',
  `test_result_showhtml` tinyint(3) unsigned NOT NULL default '0',
  `test_result_showpdf` tinyint(3) unsigned NOT NULL default '0',
  `test_result_rtemplateid` int(10) unsigned NOT NULL default '0',
  `test_reportgradecondition` tinyint(3) unsigned NOT NULL default '0',
  `test_result_email` varchar(255) NOT NULL default '',
  `test_result_emailtouser` tinyint(3) unsigned NOT NULL default '0',
  `test_datestart` int(10) unsigned NOT NULL default '0',
  `test_dateend` int(10) unsigned NOT NULL default '0',
  `test_prevtestid` int(10) unsigned NOT NULL default '0',
  `test_nexttestid` int(10) unsigned NOT NULL default '0',
  `test_contentprotection` tinyint(3) unsigned NOT NULL default '0',
  `test_notes` text NOT NULL,
  `test_price` int(10) unsigned NOT NULL default '0',
  `test_other_repeatuntilcorrect` tinyint(3) unsigned NOT NULL default '0',
  `test_forall` tinyint(3) unsigned NOT NULL default '1',
  `test_createdate` int(10) unsigned NOT NULL default '0',
  `test_enabled` tinyint(3) unsigned NOT NULL default '1',
  PRIMARY KEY  (`testid`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=latin1 */;

DROP TABLE IF EXISTS `tracnghiem_tests_attempts`;
CREATE TABLE `tracnghiem_tests_attempts` (
  `testid` int(10) unsigned NOT NULL default '0',
  `userid` int(10) unsigned NOT NULL default '0',
  `test_attempt_count` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`testid`,`userid`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=latin1 */;

DROP TABLE IF EXISTS `tracnghiem_tests_own`;
CREATE TABLE `tracnghiem_tests_own` (
  `testid` int(10) unsigned NOT NULL default '0',
  `userid` int(10) unsigned NOT NULL default '0',
  `test_own_expiredate` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`testid`,`userid`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=latin1 */;

DROP TABLE IF EXISTS `tracnghiem_tests_questions`;
CREATE TABLE `tracnghiem_tests_questions` (
  `test_questionid` int(10) unsigned NOT NULL default '0',
  `testid` int(10) unsigned NOT NULL default '0',
  `test_sectionid` int(10) unsigned NOT NULL default '0',
  `questionid` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`testid`,`test_questionid`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=latin1 */;

DROP TABLE IF EXISTS `tracnghiem_users`;
CREATE TABLE `tracnghiem_users` (
  `userid` int(10) unsigned NOT NULL auto_increment,
  `user_name` varchar(255) NOT NULL default '',
  `user_passhash` varchar(32) NOT NULL default '',
  `user_checkword` varchar(32) NOT NULL default '',
  `user_email` varchar(255) NOT NULL default '',
  `user_title` varchar(32) NOT NULL default '',
  `user_firstname` varchar(255) NOT NULL default '',
  `user_lastname` varchar(255) NOT NULL default '',
  `user_middlename` varchar(255) NOT NULL default '',
  `user_address` text NOT NULL,
  `user_city` varchar(255) NOT NULL default '',
  `user_state` varchar(255) NOT NULL default '',
  `user_zip` varchar(255) NOT NULL default '',
  `user_country` varchar(255) NOT NULL default '',
  `user_phone` varchar(255) NOT NULL default '',
  `user_fax` varchar(255) NOT NULL default '',
  `user_mobile` varchar(255) NOT NULL default '',
  `user_pager` varchar(255) NOT NULL default '',
  `user_ipphone` varchar(255) NOT NULL default '',
  `user_webpage` varchar(255) NOT NULL default '',
  `user_icq` varchar(255) NOT NULL default '',
  `user_msn` varchar(255) NOT NULL default '',
  `user_aol` varchar(255) NOT NULL default '',
  `user_gender` tinyint(4) NOT NULL default '0',
  `user_birthday` datetime NOT NULL default '1900-01-01 00:00:00',
  `user_husbandwife` varchar(255) NOT NULL default '',
  `user_children` varchar(255) NOT NULL default '',
  `user_trainer` varchar(255) NOT NULL default '',
  `user_photo` varchar(255) NOT NULL default '',
  `user_company` varchar(255) NOT NULL default '',
  `user_cposition` varchar(255) NOT NULL default '',
  `user_department` varchar(255) NOT NULL default '',
  `user_coffice` varchar(255) NOT NULL default '',
  `user_caddress` text NOT NULL,
  `user_ccity` varchar(255) NOT NULL default '',
  `user_cstate` varchar(255) NOT NULL default '',
  `user_czip` varchar(255) NOT NULL default '',
  `user_ccountry` varchar(255) NOT NULL default '',
  `user_cphone` varchar(255) NOT NULL default '',
  `user_cfax` varchar(255) NOT NULL default '',
  `user_cmobile` varchar(255) NOT NULL default '',
  `user_cpager` varchar(255) NOT NULL default '',
  `user_cipphone` varchar(255) NOT NULL default '',
  `user_cwebpage` varchar(255) NOT NULL default '',
  `user_cphoto` varchar(255) NOT NULL default '',
  `user_ufield1` text NOT NULL,
  `user_ufield2` text NOT NULL,
  `user_ufield3` text NOT NULL,
  `user_ufield4` text NOT NULL,
  `user_ufield5` text NOT NULL,
  `user_ufield6` text NOT NULL,
  `user_ufield7` text NOT NULL,
  `user_ufield8` text NOT NULL,
  `user_ufield9` text NOT NULL,
  `user_ufield10` text NOT NULL,
  `user_notes` text NOT NULL,
  `user_joindate` int(10) unsigned NOT NULL default '0',
  `user_logindate` int(10) unsigned NOT NULL default '0',
  `user_expiredate` int(10) unsigned NOT NULL default '0',
  `user_enabled` tinyint(3) unsigned NOT NULL default '1',
  PRIMARY KEY  (`userid`)
) ENGINE=MyISAM AUTO_INCREMENT=4 /*!40101 DEFAULT CHARSET=latin1 */;

INSERT INTO `tracnghiem_users` VALUES
(1, 'Vũ Thanh Lai', 'd7e305d30f10f87a6ba075026406102a', '', 'vuthanhlai@gmail.com', '', 'Vũ Thanh', 'Lai', '', '667, Khu: 13, TT: Định quán', 'Định quán', 'Đồng nai', '', 'Việt nam', '', '', '0902595020', '', '', 'tanphu.net', '', '', '', 1, '1900-01-01 00:00:00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1216455003, 1216456299, 0, 1),
(2, 'guest', '36ae6fd873e5b378211807c1a3f35521', '', 'vuthanhlai@gmail.com', '', 'Khách', 'User', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '1900-01-01 00:00:00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1216455003, 1216455003, 0, 1),
(3, 'LaiVip1', '202cb962ac59075b964b07152d234b70', '1c1phmh7', 'vuthanhlai1@gmail.com', '', 'Vũ Thanh', 'Lai', '', '12a2, tân phú', 'Định quán', 'đồng nai', '', 'VN', '', '', '', '', '', '', '', '', '', 1, '1900-01-01 00:00:00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '12a2', 'Tân Phú', '', '', '', '', '', '', '', '', '', 1216455573, 0, 0, 1);

DROP TABLE IF EXISTS `tracnghiem_visitors`;
CREATE TABLE `tracnghiem_visitors` (
  `visitorid` int(10) unsigned NOT NULL auto_increment,
  `startdate` int(10) unsigned NOT NULL default '0',
  `enddate` int(10) unsigned NOT NULL default '0',
  `userid` int(10) unsigned NOT NULL default '0',
  `ip1` tinyint(3) unsigned NOT NULL default '0',
  `ip2` tinyint(3) unsigned NOT NULL default '0',
  `ip3` tinyint(3) unsigned NOT NULL default '0',
  `ip4` tinyint(3) unsigned NOT NULL default '0',
  `host` varchar(100) NOT NULL default '',
  `referer` varchar(255) NOT NULL default '',
  `useragent` varchar(255) NOT NULL default '',
  `hits` int(10) unsigned NOT NULL default '0',
  `inurl` varchar(255) NOT NULL default '',
  `outurl` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`visitorid`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=latin1 */;

